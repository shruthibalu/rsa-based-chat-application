from django.apps import AppConfig


class RsademoConfig(AppConfig):
    name = 'rsaDemo'
